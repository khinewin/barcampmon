<footer  class="navbar navbar-fixed-bottom" id="footer">

        <div class="text-center">
            <p>&copy; Copyright Barcamp Mon. All rights reserved.</p>
            <p>Developed by <strong style="color: #ffffff">Pymyo Swe (CU Thaton)</strong></p>

        </div>


</footer> <!--/#footer-->





